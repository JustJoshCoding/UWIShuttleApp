package com.project.uwishuttleapp;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Activity_Student_Login extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_portal);
        TextView v1 = (TextView) findViewById (R.id.textview2);
        TextView v2 = (TextView) findViewById (R.id.textView4);
        TextView v3 = (TextView) findViewById (R.id.textView5);




//        student.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Activity2.this, MainActivity.class);
//
//                startActivity(intent);
//                finish();
//            }
        //});

    }

}
