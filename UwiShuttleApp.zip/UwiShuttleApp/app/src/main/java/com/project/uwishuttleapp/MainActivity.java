package com.project.uwishuttleapp;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);
        TextView welcome = (TextView) findViewById (R.id.welcomeInfo);
        ImageButton student = (ImageButton) findViewById(R.id.student);
        ImageButton driver = (ImageButton) findViewById(R.id.driver);



        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(MainActivity.this, Activity_Student_Login.class);

                    startActivity(intent);
                    finish();
                }
                catch(Exception e)
                {
                    System.out.println(" THIS IS MY ERROR "+ e);
                }

            }
        });

        driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(MainActivity.this, Activity_Driver_Login.class);

                    startActivity(intent);
                    finish();
                }
                catch(Exception e)
                {
                    System.out.println(" THIS IS MY ERROR "+ e);
                }

            }
        });




    }
}